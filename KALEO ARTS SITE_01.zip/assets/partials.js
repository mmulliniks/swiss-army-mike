// Kaleo — reusable partial renderers
window.KP = (function() {
  const C = window.KALEO_COPY;

  // Ticker with custom messages + variant color (default gold)
  const ticker = (messages, variant = '') => `
    <div class="ticker ${variant}">
      <div class="ticker-track">
        ${Array.from({length: 2}).map(() => `
          <span>
            ${messages.map(m => `
              <span>${m}</span><span class="diamond">\u25c6</span>
            `).join('')}
          </span>
        `).join('')}
      </div>
    </div>`;

  // Arrow icon (used in CTA buttons)
  const arrow = () => `<svg width="16" height="12" viewBox="0 0 16 12"><path d="M2 6h12m-4-4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  // Arrow-up-right icon
  const arrowNE = () => `<svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 11L11 3m0 0H4.5M11 3v6.5" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  // Star icon
  const star = () => `<svg width="36" height="36" viewBox="0 0 36 36"><path d="M18 2l3.5 12L34 18l-12.5 4L18 34l-3.5-12L2 18l12.5-4z" fill="currentColor"/></svg>`;

  // Section: heart values (used on Home and About)
  const heart = (heart) => `
    <section class="heart reveal">
      <div class="container">
        <h2 class="heart-title">${heart.heading.pre} <em>${heart.heading.italic}</em>${heart.heading.tail || ''}</h2>
        <p class="heart-sub">${heart.sub}</p>
        <div class="values">
          ${heart.values.map((v, i) => `
            <div class="value reveal r-d${i+1}">
              <div class="value-star">${star()}</div>
              <h3>${v.title}</h3>
              <p>${v.body}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>`;

  // Section: testimonials (3 cards)
  const testimonials = (list, headingParts) => `
    <section class="testi">
      <div class="container">
        ${headingParts ? `
          <h2 class="testi-head reveal">${headingParts.pre} <em>${headingParts.italic}</em>${headingParts.tail || ''}</h2>
        ` : ''}
        <div class="testi-grid">
          ${list.map((t, i) => `
            <div class="testi-card reveal r-d${i+1}">
              <p>\u201c${t.quote}\u201d</p>
              <cite>\u2014 ${t.who}</cite>
            </div>
          `).join('')}
        </div>
      </div>
    </section>`;

  // Pull-quote strip
  const pullquote = (text) => `
    <section class="pullquote reveal">
      <div class="container">
        <p>\u201c${text}\u201d</p>
      </div>
    </section>`;

  // Stat strip
  const statStrip = (stats) => `
    <section class="reveal">
      <div class="container">
        <div class="stat-strip">
          ${stats.map(s => `
            <div class="stat">
              <div class="n">${s.n}</div>
              <div class="lbl">${s.lbl}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </section>`;

  // Lead form (with iClassPro embed placeholder above)
  const leadForm = (lf) => `
    <div class="lead-form">
      <h3>${lf.heading.pre} <em>${lf.heading.italic}</em>${lf.heading.tail ? ' ' + lf.heading.tail : ''}</h3>
      <p class="lf-sub">${lf.sub}</p>
      <form onsubmit="event.preventDefault(); this.querySelector('button').innerHTML='\u2713 Sent \u2014 we\\'ll be in touch'; this.querySelector('button').classList.add('btn-gold');">
        ${lf.fields.map(f => `
          <label class="field">
            <label>${f.label}</label>
            ${f.type === 'select' ? `
              <select name="${f.name}">
                <option value="">Choose one\u2026</option>
                ${f.options.map(o => `<option>${o}</option>`).join('')}
              </select>
            ` : `
              <input type="${f.type}" name="${f.name}" placeholder="${f.placeholder || ''}" />
            `}
          </label>
        `).join('')}
        <button class="btn btn-primary" type="submit">${lf.cta} ${arrow()}</button>
      </form>
      <div class="lead-form-note">or call (248) 555\u20130123 \u00b7 no obligation</div>
    </div>`;

  // iClassPro embed placeholder (would be replaced with real iframe)
  // iClassPro live registration button. Deep-links straight to your portal.
  const iClassEmbed = (programName) => `
    <div class="iclass-embed">
      <div class="ic-eye">\u25c6 Registration \u00b7 Powered by iClassPro</div>
      <h4>Register for <em>${programName}</em></h4>
      <p>See live class schedules, availability, and register right through our iClassPro portal.</p>
      <div class="iclass-cta">
        <a href="https://portal.iclasspro.com/kaleoarts/classes" target="_blank" rel="noopener">
          <img style="width: 173px; height: 35px; border: 0;" alt="Class Schedules" src="https://mktg.iclasspro.com/portal/ClassSchedules.png" />
        </a>
      </div>
      <div class="iclass-hint">Opens the Kaleo Arts iClassPro portal in a new tab.</div>
    </div>`;

  // Final CTA
  const finalCta = (final) => `
    <section class="final-cta">
      <div class="container">
        <span class="eyebrow-c reveal">\u2726 ${final.eye}</span>
        <h2 class="reveal r-d1">${final.heading.pre}<br/><em>${final.heading.italic}</em></h2>
        <p class="reveal r-d2">${final.body}</p>
        <div class="cta-row reveal r-d3">
          <a class="btn btn-primary" href="enroll.html">${final.primary} ${arrow()}</a>
          ${final.secondary ? `<a class="btn btn-secondary" href="enroll.html">${final.secondary}</a>` : ''}
        </div>
      </div>
    </section>`;

  // Location block
  const location = () => {
    const l = C.home.location;
    return `
    <section class="loc container">
      <div class="loc-map reveal">
        <div class="grid"></div>
        <div class="road" style="left:0;right:0;top:52%;height:14px;"></div>
        <div class="road" style="top:0;bottom:0;left:44%;width:10px;"></div>
        <div class="loc-pin">
          <div class="label">KALEO ARTS \u2726</div>
          <div class="dot"></div>
        </div>
        <div style="position:absolute; left:14px; bottom:12px; font-family:'JetBrains Mono',monospace; font-size:10px; color:rgba(244,233,210,.4); letter-spacing:0.08em;">
          [ MAP \u00b7 N. ADAMS \u00d7 OAKLAND TWP \u00b7 placeholder ]
        </div>
      </div>
      <div class="loc-body reveal r-d1">
        <h2>${l.heading.pre} <em>${l.heading.italic}</em> ${l.heading.tail}</h2>
        <p>${l.body}</p>
        <div class="loc-details">
          <div><span>Address</span><span>4818 N. Adams Rd., Ste B-100</span></div>
          <div><span>City</span><span>Oakland Township, MI 48306</span></div>
          <div><span>Opening</span><span>Fall 2026</span></div>
        </div>
        <a class="btn btn-primary" href="enroll.html">${l.cta} ${arrow()}</a>
      </div>
    </section>`;
  };

  return { ticker, arrow, arrowNE, star, heart, testimonials, pullquote, statStrip, leadForm, iClassEmbed, finalCta, location };
})();
