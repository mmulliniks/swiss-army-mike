// Kaleo Arts — nav + footer chrome, injected into every page.
// Each page sets `window.__page = 'home' | 'kaleo-kids' | ...` before including this.
(function() {
  const C = window.KALEO_COPY;
  const page = window.__page || '';

  // -------- Lights strip --------
  const lightsHTML = `
  <div class="lights">
    ${Array.from({length: 30}).map(() => '<span></span>').join('')}
  </div>`;

  // -------- Nav --------
  const isProgram = C.nav.programs.some(p => p.key === page);
  const navHTML = `
  <nav class="nav">
    <div class="nav-inner">
      <a class="logo" href="index.html">
        <span class="logo-mark">K</span>
        <span>Kaleo <em>Arts</em></span>
      </a>
      <button class="mobile-toggle" aria-label="Menu">
        <svg width="20" height="20" viewBox="0 0 20 20"><path d="M3 6h14M3 10h14M3 14h14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
      </button>
      <div class="nav-links">
        <div class="nav-dropdown">
          <a href="#" class="${isProgram ? 'current' : ''}">Programs
            <svg viewBox="0 0 10 10" width="10" height="10"><path d="M1 3l4 4 4-4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>
          </a>
          <div class="nav-dropdown-menu">
            ${C.nav.programs.map(p => `
              <a href="${p.href}">
                <strong>${p.label}</strong>
                <span>${p.sub}</span>
              </a>
            `).join('')}
          </div>
        </div>
        ${C.nav.top.map(t => `
          <a href="${t.href}" class="${page === t.label.toLowerCase() ? 'current' : ''}">${t.label}</a>
        `).join('')}
        <a class="enroll-btn" href="${C.nav.cta.href}">${C.nav.cta.label} \u2192</a>
      </div>
    </div>
  </nav>`;

  // -------- Footer --------
  const footerHTML = `
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a class="logo" href="index.html" style="display:inline-flex;">
            <span class="logo-mark">K</span>
            <span>Kaleo <em>Arts</em></span>
          </a>
          <p>Where art, joy &amp; community collide.</p>
          <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:rgba(244,233,210,.5); letter-spacing:0.04em; line-height:1.55;">
            4818 N. ADAMS RD., SUITE B-100<br/>
            OAKLAND TOWNSHIP, MI 48306
          </div>
        </div>
        ${C.footer.columns.map(col => `
          <div>
            <h4>${col.heading}</h4>
            <ul>${col.links.map(l => `<li><a href="${l.href}">${l.label}</a></li>`).join('')}</ul>
          </div>
        `).join('')}
      </div>
      <div class="footer-bottom">
        <span>\u00a9 2026 KALEO ARTS</span>
        <span>MADE WITH HEART IN OAKLAND TWP.</span>
      </div>
    </div>
  </footer>`;

  // Inject into slots
  const lightsSlot = document.getElementById('lights-slot');
  const navSlot    = document.getElementById('nav-slot');
  const footerSlot = document.getElementById('footer-slot');
  if (lightsSlot) lightsSlot.outerHTML = lightsHTML;
  if (navSlot)    navSlot.outerHTML = navHTML;
  if (footerSlot) footerSlot.outerHTML = footerHTML;
})();
