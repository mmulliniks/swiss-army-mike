// Kaleo Arts — shared JS (nav, reveal, faq)
(function() {
  // -------- Scroll reveal --------
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('is-in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.05, rootMargin: '0px 0px -40px 0px' });

  const observeReveal = () => {
    document.querySelectorAll('.reveal:not(.is-in)').forEach(el => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.9) {
        el.classList.add('is-in');
      } else {
        io.observe(el);
      }
    });
  };
  window.__observeReveal = observeReveal;
  document.addEventListener('DOMContentLoaded', () => setTimeout(observeReveal, 60));
  setTimeout(() => {
    document.querySelectorAll('.reveal:not(.is-in)').forEach(el => el.classList.add('is-in'));
  }, 3000);

  // -------- Mobile nav toggle --------
  document.addEventListener('click', (e) => {
    if (e.target.closest('.mobile-toggle')) {
      document.querySelector('.nav-links')?.classList.toggle('mobile-open');
    }
  });

  // -------- FAQ accordion --------
  document.addEventListener('click', (e) => {
    const q = e.target.closest('.faq-q');
    if (q) {
      const item = q.closest('.faq-item');
      item.classList.toggle('open');
    }
  });
})();
