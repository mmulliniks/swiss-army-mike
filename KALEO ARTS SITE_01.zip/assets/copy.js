// Kaleo Arts — all copy, verbatim from the site map doc
window.KALEO_COPY = {
  brand: {
    name: "Kaleo Arts",
    tagline: "Oakland Township · Opening Fall 2026",
    address: "4818 N. Adams Rd., Suite B-100, Oakland Township, MI 48306",
    meaning: "Kaleo (KA-LEH-OH) — Greek, meaning \u201cto invite.\u201d",
  },

  // ============ NAV ============
  nav: {
    programs: [
      { key: "kaleo-kids",  label: "Kaleo Kids",  sub: "K\u20135th grade",     href: "kaleo-kids.html",  color: "coral" },
      { key: "kazoo",       label: "Kazoo",       sub: "Ages 3\u20136",         href: "kazoo.html",       color: "mint" },
      { key: "songwriters", label: "Songwriters", sub: "M.S. \u2013 H.S.",      href: "songwriters.html", color: "gold" },
      { key: "classes",     label: "Classes",     sub: "All ages",              href: "classes.html",     color: "pink" },
      { key: "spark-camp",  label: "Spark Camp",  sub: "Summer, K\u20136",      href: "spark-camp.html",  color: "cranberry" },
    ],
    top: [
      { label: "About", href: "about.html" },
      { label: "FAQ",   href: "faq.html" },
    ],
    cta: { label: "Enroll", href: "enroll.html" },
  },

  // ============ HOME ============
  home: {
    hero: {
      eyebrow: "Oakland Township \u00b7 Opening Fall 2026",
      // headline broken into parts for styling
      headlineParts: {
        lead: "Where",
        one: "art,",   // italic gold
        two: "joy",    // coral glow
        amp: "&",
        three: "community", // italic gold
        tail: "collide.",
      },
      side: {
        preface: "Kaleo",
        body: "is a Greek word \u2014 it means",
        emphasis: "\u201cto invite.\u201d",
        note: "KA-LEH-OH",
      },
      ticker: [
        "Now Casting: Fall Session",
        "Sing \u00b7 Dance \u00b7 Act \u00b7 Write",
        "Ages 3 through Adult",
        "No auditions ever",
        "Enroll today",
      ],
    },
    approach: {
      heading: { pre: "Confidence,", italic: "on stage", tail: "and off." },
      body: "Our one-of-a-kind performing arts programming brings students from different communities together to develop music, dance, drama, and songwriting skills while building confidence and character. Our desire is for every child we work with to know they are valuable, creative, and capable of changing the world for the better.",
      cta: "Join today",
    },
    dont: {
      eyebrow: "Three commitments",
      heading: { pre: "Three things", strike: "don't", tail: "do." },
      items: [
        { title: "auditions",    body: "Every child gets a place, regardless of experience." },
        { title: "competitions", body: "We build confidence through practice and performance, not trophies and rankings." },
        { title: "costume fees", body: "The price you see is the price you pay." },
      ],
    },
    heart: {
      heading: { pre: "Our", italic: "heart", tail: "." },
      sub: "Three commitments that shape every class, every rehearsal, every performance we put on.",
      values: [
        { title: "Empathy.",    body: "We help kids see the joy in collaboration, teamwork, and learning to work together to create meaningful artistic moments." },
        { title: "Excellence.", body: "We set the bar higher to challenge artistic abilities and encourage kids to take risks to reach their full potential." },
        { title: "Community.",  body: "Kaleo means \u201cto invite\u201d \u2014 inviting kids to try new things, inviting communities together, inviting talent toward purpose." },
      ],
    },
    testimonials: [
      { quote: "My daughter found her voice here \u2014 literally and figuratively. No pressure, just growth.", who: "Kaleo Kids parent" },
      { quote: "We tried a competition studio first. This is the first place my son actually asks to go back to.", who: "Kaleo Kids parent" },
      { quote: "Renee remembers every kid's name and every kid's story. That's rare, and it matters.",           who: "Community member since 2019" },
    ],
    location: {
      heading: { pre: "Come", italic: "see", tail: "the space." },
      body: "We just opened our doors at a brand new studio in Oakland Township. Stop by, meet the team, watch a class in session \u2014 no appointment needed, but tours are welcome too.",
      cta: "Schedule a tour",
    },
    finalCta: {
      eye: "RSVP",
      heading: { pre: "You're", italic: "invited." },
      body: "Come see what an invitation feels like. No audition required. No obligation. Just a conversation and a look around.",
      primary: "Enroll today",
      secondary: "Schedule a tour",
    },
  },

  // Program summaries used on Home + Enroll
  programs: [
    {
      key: "kaleo-kids", name: "Kaleo Kids", href: "kaleo-kids.html", color: "coral",
      grade: "K\u20135th grade", price: "$140/mo founding rate",
      body: "Our high-energy performing arts programs develop their talents and grow their character.",
      short: "Elementary students. Sing, dance, act, grow \u2014 one class a week.",
    },
    {
      key: "kazoo", name: "Kazoo", href: "kazoo.html", color: "mint",
      grade: "Ages 3\u20136", price: "$85/mo",
      body: "Kazoo gives younger children an exciting first experience of music, movement, and storytelling.",
      short: "Preschoolers. Music, movement, and storytelling in 30-minute classes.",
    },
    {
      key: "songwriters", name: "Songwriters", href: "songwriters.html", color: "gold",
      grade: "M.S. \u2013 H.S.", price: "Pricing on request",
      body: "Middle and high school artists who collaborate and use their gifts to create original songs.",
      short: "Middle and high schoolers writing original music, live with a band.",
    },
    {
      key: "classes", name: "Classes", href: "classes.html", color: "pink",
      grade: "All ages", price: "Pricing on request",
      body: "Show choir, tap, theater, and visual arts \u2014 group classes shaped by what our community asks for.",
      short: "Adults and kids. Show choir, tap, theater, visual arts, and more.",
    },
    {
      key: "spark-camp", name: "Spark Camp", href: "spark-camp.html", color: "cranberry",
      grade: "K\u20136th grade", price: "One week, summer only",
      body: "A one-week summer camp ending in a full musical theater production.",
      short: "One week of music, dance, drama, art \u2014 ends with a real show.",
    },
  ],

  // ============ KALEO KIDS ============
  kaleoKids: {
    hero: {
      eyebrow: "K\u20135th grade \u00b7 The flagship program",
      headline: { pre: "Welcome to", italic: "Kaleo Kids", tail: "\u2014 where it all started." },
      subhead: "Your child is cast in a role in an original stage production. Every class blends singing, dancing, and acting, plus a community time lesson that builds character alongside the craft.",
      cta: "Claim a risk-free trial",
    },
    pullQuote: "No auditions to join. No competitions. No costume fees. Just kids discovering what they're capable of.",
    stats: [
      { n: "2005",   lbl: "Our first production" },
      { n: "100s",   lbl: "Of performances since" },
      { n: "1,000s", lbl: "Of young performers" },
    ],
    fourClasses: {
      heading: { pre: "Four classes", italic: "in one." },
      sub: "Every Kaleo Kids session rotates through three disciplines, plus a weekly community time lesson.",
      items: [
        { title: "Singing.",       body: "Learning the score that carries their production." },
        { title: "Dancing.",       body: "Choreography built for the show they're part of." },
        { title: "Acting.",        body: "Bringing their character to life, line by line." },
        { title: "Community time.", body: "A weekly lesson built around character, not just craft." },
      ],
      note: "All in", noteStrong: "one hour and forty-five minutes,", noteEnd: "one day a week.",
    },
    fiveShine: {
      heading: { pre: "Five times to", italic: "shine." },
      body: "Five sessions a year, five live stage performances. Not a three-hour recital where your child is on stage for five minutes \u2014 a showcase built around their class, where they're truly part of the story. Real stage, real lights, real audience.",
    },
    enroll: {
      priceEye: "Founding rate",
      priceBig: "$140",
      priceUnit: "/month",
      priceNote: "Locked for your first year (regular rate $155\u2013177/mo).",
      heading: { pre: "One class a week.", italic: "One community." },
      includes: [
        "One 1h 45m class per week \u2014 singing, dancing, acting, community time",
        "K\u20135th grade, no experience or audition required",
        "Five sessions a year, five live stage performances",
        "No costume fees, no competition entry fees",
        "Risk-free trial for new students",
      ],
      cta: "Claim my risk-free trial",
    },
    founderStory: {
      heading: { pre: "Where Kaleo", italic: "began." },
      body: [
        "Kaleo Kids is where Kaleo Arts began. Since our first production in 2005, we've had hundreds of performances and thousands of young performers under our lights \u2014 all without a single audition.",
        "Kaleo Kids is led by Renee Mulliniks, who founded the program as a simple experiment: could kids who'd never set foot on a stage pull off an original production? Two decades later, it's Kaleo's flagship.",
      ],
    },
    testimonials: [
      { quote: "My daughter found her voice here \u2014 literally and figuratively.", who: "Kaleo Kids parent" },
      { quote: "This is the first place my son actually asks to go back to.",         who: "Kaleo Kids parent" },
      { quote: "Watching him on a real stage \u2014 that's different from a five-minute recital slot.", who: "Kaleo Kids parent" },
    ],
    leadForm: {
      heading: { pre: "Claim your", italic: "risk-free trial." },
      sub: "We'll call or text you within the hour to get your child started.",
      fields: [
        { name: "parent",  label: "Parent name",       type: "text",  placeholder: "First and last" },
        { name: "phone",   label: "Phone number",      type: "tel",   placeholder: "(555) 555-5555" },
        { name: "grade",   label: "Child's grade",     type: "select", options: ["K", "1st", "2nd", "3rd", "4th", "5th"] },
      ],
      cta: "Book my trial",
    },
  },

  // ============ KAZOO ============
  kazoo: {
    hero: {
      eyebrow: "Ages 3\u20136 \u00b7 Early childhood music & movement",
      headline: { pre: "It's never too", italic: "early", tail: "to discover your voice." },
      subhead: "Kazoo is our early-childhood program \u2014 a joyful, age-appropriate introduction to the performing arts, where your little one learns to find the beat, match a pitch, and most importantly, have fun.",
      cta: "Find a Kazoo class",
    },
    pullQuote: "Your little one is already musical. We can see it too.",
    howItWorks: {
      heading: { pre: "How", italic: "it works." },
      items: [
        { title: "Music to ballet.",     body: "A variety of Kazoo classes, so you can find the style your child lights up for." },
        { title: "30 minutes each.",     body: "Sized for little attention spans \u2014 many families enroll in more than one." },
        { title: "Open Play add-on.",    body: "Explore instruments, costumes, and puppets together, with our staff alongside you." },
      ],
    },
    whyItWorks: {
      pullQuote: "They're playing \u2014 and growing \u2014 at the same time.",
      body: [
        "Our curriculum is rooted in research showing that music paired with cross-body movement accelerates coordination, development, and neural connections in young children.",
        "Every class is built around that idea: keep it joyful, keep it moving, and let the learning happen alongside the fun.",
      ],
    },
    openPlay: {
      heading: { pre: "Add on", italic: "Open Play." },
      body: "An experience where you and your child explore musical instruments, costumes, puppets, and more \u2014 all with our staff right there alongside you.",
    },
    enroll: {
      priceBig: "$85",
      priceUnit: "/month",
      heading: { pre: "A joyful", italic: "first stage." },
      includes: [
        "30-minute classes, ages 3\u20136",
        "Choose from music, ballet, and more",
        "Option to enroll in more than one class",
        "Open Play add-on available",
        "No experience or audition required",
      ],
      cta: "Find a Kazoo class",
    },
    testimonials: [
      { quote: "Open Play is the highlight of our week. My toddler asks for it by name.", who: "Kazoo parent" },
      { quote: "She's two and already humming the songs from class at home.",           who: "Kazoo parent" },
      { quote: "The teachers are so patient and warm with the little ones. It shows.", who: "Kazoo parent" },
    ],
    leadForm: {
      heading: { pre: "Find a", italic: "Kazoo class." },
      sub: "We'll call or text you within the hour to help you pick the right class.",
      fields: [
        { name: "parent", label: "Parent name",  type: "text", placeholder: "First and last" },
        { name: "phone",  label: "Phone number", type: "tel",  placeholder: "(555) 555-5555" },
        { name: "age",    label: "Child's age",  type: "select", options: ["3", "4", "5", "6"] },
      ],
      cta: "Find our class",
    },
  },

  // ============ SONGWRITERS ============
  songwriters: {
    hero: {
      eyebrow: "Middle & high school \u00b7 Original music program",
      headline: { pre: "\u201cMy kid", italic: "wrote", tail: "that.\u201d" },
      subhead: "That's what you'll tell your friends after your child's first Songwriters session. Middle and high schoolers collaborate to write original music, guided by our professional production and songwriting team.",
      cta: "Learn more",
    },
    pullQuote: "No audition required. All middle and high schoolers are welcome.",
    howItWorks: {
      heading: { pre: "How a session", italic: "works." },
      items: [
        { title: "Write together.", body: "Your student collaborates with peers, guided by professional songwriters." },
        { title: "Produce it.",     body: "Original songs take shape with our music production team." },
        { title: "Perform it live.", body: "Finished songs performed live with a band of professional musicians." },
      ],
    },
    whyItMatters: {
      heading: { pre: "Why", italic: "it matters." },
      body: [
        "Over the past decade, the songs Kaleo Songwriters have written are a real testament to what young people are capable of when they're given the space, the support, and the tools to create.",
        "Watching this age group share their ideas, work through feedback together, and refine their craft in a safe and nurturing environment has produced some of the most meaningful breakthroughs in confidence and expression we've ever witnessed at Kaleo.",
        "Each year, some songs from our Songwriters classes are professionally recorded and released on streaming platforms for the world to hear.",
      ],
    },
    albums: {
      heading: { pre: "Hear what students have", italic: "made." },
      sub: "Albums released over the years.",
      items: [
        { title: "Chosen",       year: "2024" },
        { title: "Overflow",     year: "2023" },
        { title: "The Invitation", year: "2022" },
        { title: "New Song",     year: "2021" },
        { title: "Louder",       year: "2020" },
        { title: "Anthem",       year: "2019" },
      ],
    },
    enroll: {
      priceEye: "Session pricing",
      priceBig: "Contact us",
      priceNote: "Contact for current session pricing.",
      heading: { pre: "Bring your", italic: "songwriter", tail: "to Kaleo." },
      includes: [
        "Middle and high school students",
        "No audition or songwriting experience required",
        "Guided by professional songwriters and producers",
        "Live performance with a professional band",
        "Chance for songs to be recorded and released",
      ],
      cta: "Learn more",
    },
    leadForm: {
      heading: { pre: "Bring your songwriter to", italic: "Kaleo." },
      sub: "We'll call or text you within the hour to talk through the next session.",
      fields: [
        { name: "name",  label: "Parent or student name", type: "text", placeholder: "First and last" },
        { name: "phone", label: "Phone number",           type: "tel",  placeholder: "(555) 555-5555" },
        { name: "grade", label: "Grade level",            type: "select", options: ["6th", "7th", "8th", "9th", "10th", "11th", "12th"] },
      ],
      cta: "Tell us more",
    },
  },

  // ============ CLASSES ============
  classes: {
    hero: {
      eyebrow: "All ages \u00b7 Group classes, shaped by community demand",
      headline: { pre: "Something here for", italic: "everyone." },
      subhead: "Group Classes are Kaleo's twist on a traditional one-hour studio class \u2014 from show choir to tap, theater to visual arts, for kids sharpening their skills and adults looking for a creative outlet.",
      cta: "See current classes",
    },
    lineup: {
      heading: { pre: "Current", italic: "lineup." },
      items: [
        { name: "Theater",              audience: "Middle & high school", body: "Scene work, stagecraft, and performance fundamentals.", color: "coral" },
        { name: "Group vocal",          audience: "Middle & high school", body: "Ensemble singing and vocal technique.",                 color: "mint" },
        { name: "Tap",                  audience: "Adults",               body: "A fun, low-pressure creative outlet after a long day.", color: "gold" },
        { name: "Choir club",           audience: "Adults",               body: "Sing with a community of other adults, no experience required.", color: "pink" },
        { name: "Guest artist classes", audience: "Rotating",             body: "Local guest artists featured throughout the year.",     color: "cranberry" },
        { name: "Visual arts",          audience: "Coming soon",          body: "New offerings shaped by what our community asks for.",  color: "coral" },
      ],
    },
    shapedByYou: {
      heading: { pre: "Shaped by", italic: "you." },
      body: [
        "We build the community so you can find your people.",
        "What makes our group classes unique is that they're shaped by you \u2014 we build our offerings based on what our community tells us they want, so the lineup is always evolving. Check back often; there's always something new.",
      ],
    },
    leadForm: {
      heading: { pre: "Find your", italic: "class." },
      sub: "Tell us who's enrolling and we'll follow up with current openings.",
      fields: [
        { name: "name",  label: "Name",           type: "text", placeholder: "First and last" },
        { name: "phone", label: "Phone number",   type: "tel",  placeholder: "(555) 555-5555" },
        { name: "who",   label: "Who's this for?", type: "select", options: ["My child", "Myself", "Both"] },
      ],
      cta: "Send it",
    },
  },

  // ============ SPARK CAMP ============
  sparkCamp: {
    hero: {
      eyebrow: "K\u20136th grade \u00b7 One week, every summer",
      headline: { pre: "Every summer, something", italic: "incredible", tail: "happens." },
      subhead: "For one action-packed week, your camper dives into music, dance, drama, and art \u2014 rotating through each discipline every day, in a joyful, faith-filled environment.",
      cta: "Save my spot",
    },
    week: {
      heading: { pre: "Five days,", italic: "one show." },
      sub: "After just five days, your camper steps onto a professional stage and performs in a full musical theater production \u2014 original music, real lights, a real audience.",
      days: [
        { day: "Day 1", title: "Music",  body: "Finding rhythm" },
        { day: "Day 2", title: "Dance",  body: "Choreography" },
        { day: "Day 3", title: "Drama",  body: "Storytelling" },
        { day: "Day 4", title: "Art",    body: "Creative expression" },
        { day: "Day 5", title: "Showtime", body: "Live performance" },
      ],
    },
    communityTime: {
      heading: { pre: "More than", italic: "performing." },
      body: [
        "Each day includes Community Time, where campers come together for games, skits, and a lesson built around our theme for the week. It's where friendships form and kids discover they are known, loved, and valued exactly as they are.",
        "You don't have to attend church to be part of Spark Camp. Every child and every family is welcome.",
      ],
    },
    staff: {
      heading: { pre: "Staffed by people who", italic: "genuinely care." },
      body: "An amazing team of staff and volunteers who genuinely care about every child who walks through the door \u2014 that's what makes the week work. We can't wait to meet your camper.",
    },
    leadForm: {
      heading: { pre: "Save your camper's", italic: "spot." },
      sub: "We'll call or text you with this summer's dates and details.",
      fields: [
        { name: "parent", label: "Parent name",     type: "text", placeholder: "First and last" },
        { name: "phone",  label: "Phone number",    type: "tel",  placeholder: "(555) 555-5555" },
        { name: "grade",  label: "Camper's grade",  type: "select", options: ["K", "1st", "2nd", "3rd", "4th", "5th", "6th"] },
      ],
      cta: "Save my spot",
    },
  },

  // ============ ABOUT ============
  about: {
    hero: {
      eyebrow: "Who we are",
      headline: { pre: "Twenty years of teaching in this community,", italic: "one relationship", tail: "at a time." },
      subhead: "Hi, I'm Renee Mulliniks, and welcome to Kaleo Arts.",
    },
    story: {
      heading: { pre: "Our", italic: "story." },
      body: [
        "Twenty years ago, we started Kaleo with a simple belief \u2014 that every child deserves a place to build confidence and discover their own creativity. The word Kaleo is a Greek word that means \u201cto invite.\u201d And that's exactly what we're doing: we're inviting you and your family in.",
        "You might be wondering \u2014 are we a dance studio? A theater program? A place for music lessons? The answer is\u2026 yes. But we're something more than all of that. Kaleo is a place where the performing arts are a vehicle for something bigger \u2014 helping kids find their voice, grow in confidence, and learn to express themselves in ways that stay with them long after they leave our stage.",
        "We do that through a multidisciplinary approach, developing kids in singing, dancing, and acting all at once. No auditions to join. No competitions. No costume fees. Kaleo is a creative home for your whole family.",
        "A huge part of what makes this place special is our teaching staff. Many have had successful professional careers as performers, musicians, and artists in their own right \u2014 and they bring that experience into every class. But what truly sets them apart is that they genuinely love the kids they teach. They know each child by name.",
      ],
      signature: "\u2014 Renee Mulliniks, Founder",
    },
    heart: {
      heading: { pre: "Our", italic: "heart", tail: "." },
      sub: "Three commitments that shape every class, every rehearsal, every performance we put on.",
      values: [
        { title: "Empathy.",    body: "We help kids see the joy in collaboration, teamwork, and learning to work together to create meaningful artistic moments." },
        { title: "Excellence.", body: "We set the bar higher to challenge artistic abilities and encourage kids to take risks to reach their full potential." },
        { title: "Community.",  body: "Kaleo means \u201cto invite\u201d \u2014 inviting kids to try new things, inviting communities together, inviting talent toward purpose." },
      ],
    },
    nonprofit: {
      eyebrow: "Nonprofit partnership with Abide Ministries",
      heading: { pre: "Making sure", italic: "all are invited." },
      body: [
        "We've always believed the performing arts should be available to every child, not just the ones who can afford it. Through our fiscal sponsorship with Abide Ministries, we operate a portion of Kaleo as a nonprofit \u2014 making sure all are truly invited, regardless of location or financial situation.",
        "Through the support of organizations like Kensington Church and the generosity of our donors, we've partnered with school districts including Mt. Clemens, Utica, and Pontiac Public Schools, where we currently serve over 1,000 kids per week through daytime programming \u2014 the same quality, the same energy, and the same heart that drives everything we do.",
      ],
      stats: [
        { n: "1,000+", lbl: "Kids served weekly through school partnerships" },
        { n: "20",     lbl: "Years in the community" },
      ],
      donationNote: "All donations to Kaleo's community programs are tax-deductible through our partnership with Abide Ministries. Whether it's a one-time gift or an ongoing partnership, your generosity helps us reach more kids and keep the invitation open to everyone.",
      cta: "Support our community programs",
    },
  },

  // ============ FAQ ============
  faq: {
    hero: {
      eyebrow: "Frequently Asked Questions",
      headline: { pre: "Answers,", italic: "in one place." },
      subhead: "Everything a new family typically wants to know before their first class. If we missed something, reach out \u2014 we'll gladly talk it through.",
    },
    groups: [
      {
        heading: "Getting started",
        items: [
          { q: "What happens at a trial class?", a: "You and your child join a real class alongside current students \u2014 no separate \u201csample\u201d session. Your child jumps into the rotation and gets a feel for singing, dancing, and acting side by side with the group they'd actually be joining." },
          { q: "What age or grade is each program for?", a: "Kazoo is ages 3\u20136. Kaleo Kids is K\u20135th grade. Songwriters and our middle/high school Group Classes are for middle and high schoolers. Spark Camp (our summer program) is K\u20136th grade. If you're not sure which fits, reach out and we'll help you figure it out." },
          { q: "Do you offer a sibling discount?", a: "Yes. Ask about current sibling pricing when you enroll." },
          { q: "Can my child enroll in more than one program?", a: "Absolutely \u2014 many families mix and match, especially with Kazoo's shorter 30-minute classes." },
        ],
      },
      {
        heading: "What to expect in class",
        items: [
          { q: "My child has never performed before \u2014 is that okay?", a: "That's most kids who walk through our doors. There are no auditions and no experience required for any program \u2014 we meet every child right where they are." },
          { q: "What does my child wear or bring?", a: "Comfortable clothes they can move in. We'll let you know if a specific class calls for anything more." },
          { q: "Can parents watch class?", a: "Yes \u2014 reach out to your program contact for specifics on observation and drop-off/pick-up." },
        ],
      },
      {
        heading: "Logistics and policies",
        items: [
          { q: "How many sessions are there per year?", a: "Kaleo Kids runs five sessions a year, each ending in a live stage performance. Other programs follow their own session calendars \u2014 ask when you enroll." },
          { q: "What if we miss a class?", a: "Reach out to your program contact about makeup options." },
          { q: "What does the end-of-session performance look like?", a: "A real stage, real lights, microphones, and a full set \u2014 built around your child's class, not a three-hour recital where they're on stage for five minutes." },
        ],
      },
      {
        heading: "Cost and access",
        items: [
          { q: "What's included in the monthly rate?", a: "Weekly class time and the end-of-session performance. We don't charge costume fees or competition entry fees \u2014 the price you see is the price you pay." },
          { q: "Do you offer financial assistance or scholarships?", a: "Yes. Through our nonprofit partnership with Abide Ministries, we're committed to making sure the invitation stays open to every family regardless of financial situation. Visit our About page or reach out directly to ask about scholarship options." },
        ],
      },
    ],
    closing: {
      heading: "Still have questions?",
      body: "We're happy to talk it through. No question is too small. Reach out and we'll help you find the right fit.",
      cta: "Enroll today",
    },
  },

  // ============ ENROLL ============
  enroll: {
    hero: {
      eyebrow: "You're invited",
      headline: { pre: "Enroll in a", italic: "Kaleo", tail: "program." },
      subhead: "Pick the program that fits your family, and every class comes with a risk-free trial. Not sure which one? Tell us a bit about your child below and we'll point you the right way.",
    },
    notSure: {
      heading: { pre: "Not sure which", italic: "fits?" },
      sub: "A quick note, and we'll point you toward the right program.",
      fields: [
        { name: "parent", label: "Parent name",  type: "text", placeholder: "First and last" },
        { name: "phone",  label: "Phone number", type: "tel",  placeholder: "(555) 555-5555" },
        { name: "age",    label: "Child's age or grade", type: "text", placeholder: "e.g. 4 years old, or 3rd grade" },
      ],
      cta: "Help me choose",
    },
  },

  // ============ FOOTER ============
  footer: {
    tagline: "Where art, joy & community collide.",
    columns: [
      { heading: "Programs", links: [
        { label: "Kaleo Kids",  href: "kaleo-kids.html" },
        { label: "Kazoo",       href: "kazoo.html" },
        { label: "Songwriters", href: "songwriters.html" },
        { label: "Classes",     href: "classes.html" },
        { label: "Spark Camp",  href: "spark-camp.html" },
      ]},
      { heading: "Visit", links: [
        { label: "About",             href: "about.html" },
        { label: "FAQ",               href: "faq.html" },
        { label: "Enroll",            href: "enroll.html" },
        { label: "Schedule a tour",   href: "enroll.html" },
        { label: "Style guide",       href: "style-guide.html" },
      ]},
      { heading: "Follow", links: [
        { label: "Instagram", href: "#" },
        { label: "Facebook",  href: "#" },
        { label: "YouTube",   href: "#" },
      ]},
    ],
  },
};
